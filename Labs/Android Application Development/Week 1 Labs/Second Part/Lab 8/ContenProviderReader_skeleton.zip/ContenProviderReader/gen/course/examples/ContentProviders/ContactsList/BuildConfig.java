/** Automatically generated file. DO NOT MODIFY */
package course.examples.ContentProviders.ContactsList;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}