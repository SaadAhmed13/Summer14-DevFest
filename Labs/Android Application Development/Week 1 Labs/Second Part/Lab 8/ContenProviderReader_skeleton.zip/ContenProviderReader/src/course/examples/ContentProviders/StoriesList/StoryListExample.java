 package course.examples.ContentProviders.StoriesList;

import course.examples.ContentProviders.ContactsList.R;
import edu.vanderbilt.mooc.provider.MoocSchema;
import android.app.ListActivity;
import android.app.LoaderManager;
import android.content.CursorLoader;
import android.content.Loader;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract.Contacts;

public class StoryListExample extends ListActivity implements
		LoaderManager.LoaderCallbacks<Cursor> {

	private StoryInfoListAdapter mAdapter;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Create and set empty adapter
		mAdapter = new StoryInfoListAdapter(this, R.layout.list_item, null, 0);
		setListAdapter(mAdapter);

		// Initialize the loader
		getLoaderManager().initLoader(0, null, this);

	}

	// Contacts data items to extract
	static final String[] STORY_COLUMNS = new String[] { //TODO: ID and Title columns here};

	// Called when a new Loader should be created
	// Returns a new CursorLoader

	@Override
	public Loader<Cursor> onCreateLoader(int id, Bundle args) {

		//TODO: your code here
	}

	// Called when the Loader has finished loading its data
	@Override
	public void onLoadFinished(Loader<Cursor> loader, Cursor data) {

		// Swap the new cursor into the List adapter
		//TODO: your code here

	}

	// Called when the last Cursor provided to onLoadFinished()
	// is about to be closed

	@Override
	public void onLoaderReset(Loader<Cursor> loader) {

		// set List adapter's cursor to null
		//TODO: your code here
	}
}