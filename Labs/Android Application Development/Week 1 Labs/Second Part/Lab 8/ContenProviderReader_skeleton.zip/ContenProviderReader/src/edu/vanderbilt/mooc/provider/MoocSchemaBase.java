// ST:BODY:start

package edu.vanderbilt.mooc.provider;

public class MoocSchemaBase {

   public static final int DATABASE_VERSION = 1;

   public static final String DATABASE_NAME = "mooc.db";

   // ST:createRelationEnum:inline
   /**
    * add elements to the enumeration as needed
    */
   public static class StoryConstants {
   } 
   /**
    * add elements to the enumeration as needed
    */
   public static class TagsConstants {
   } 
   // ST:createRelationEnum:complete
}
// ST:BODY:end