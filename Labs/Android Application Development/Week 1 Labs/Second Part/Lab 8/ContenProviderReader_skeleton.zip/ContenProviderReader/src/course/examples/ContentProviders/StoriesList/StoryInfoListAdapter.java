package course.examples.ContentProviders.StoriesList;

import java.io.FileNotFoundException;
import java.io.InputStream;

import course.examples.ContentProviders.ContactsList.R;

import edu.vanderbilt.mooc.provider.MoocSchema;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.ContactsContract.Contacts;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ResourceCursorAdapter;
import android.widget.TextView;

public class StoryInfoListAdapter extends ResourceCursorAdapter {

	private final ContentResolver mContentResolver;

	private String TAG = "ContactInfoListAdapter";

	public StoryInfoListAdapter(Context context, int layout, Cursor c,
			int flags) {

		super(context, layout, c, flags);

		mContentResolver = context.getContentResolver();

	}

	// Called when a new view is needed
	
	@Override
	public View newView(Context context, Cursor cursor, ViewGroup parent) {

		//TODO: inflate R.layout.list_item, you may need to use getSystemService(Context.LAYOUT_INFLATER_SERVICE)
	}

	// Called when a new data view is needed, but an old view is 
	// available for reuse
	
	@Override
	public void bindView(View view, Context context, Cursor cursor) {

		//TODO:
				// Set display ID
				// Set display TITLE
		}		
}
