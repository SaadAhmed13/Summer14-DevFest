package course.labs.intentsandpermissionslab;


import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;

public class ExplicitLoad extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_explicit);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_explicit, menu);
		return true;
	}
	
	public void doneClicked(View view) {
		
		EditText editText = (EditText) findViewById(R.id.editText1);
		String emailText = editText.getText().toString();
		//TODO:
		//get text from the textview 
		Intent result = new Intent("com.example.RESULT_ACTION", Uri.parse("content://result_uri"));
		//and store it in a intent which is returned to the main Activity.
		//Hint: putExtra()
		finish();
	}
}
