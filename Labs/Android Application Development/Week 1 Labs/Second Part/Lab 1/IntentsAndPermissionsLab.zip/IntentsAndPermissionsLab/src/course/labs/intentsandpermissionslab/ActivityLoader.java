package course.labs.intentsandpermissionslab;



import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;

public class ActivityLoader extends Activity {

	static final int getTextRequestCode = 1;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_loader);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_loader, menu);
		return true;
	}
	
	public void explicit(View view){
		//TODO:
		//start the ExplicitLoad activity for result. 
		//Hint: startActivityForResult(intent, getTextRequestCode);
	}
	
	public void implicit(View view){
String url = "http://www.google.com";
		
		//create an implicit intent
		Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setData(Uri.parse(url));
		
		//TODO:
		//create the App Chooser allowing you to select the built-in Browser Activity or your own MyBrowser Activity
		//Hint: Intent.createChooser
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == getTextRequestCode) {
			if (resultCode == RESULT_OK) {
				//TODO:
				//get data in the intent returned from the ExplicitLoad activity 
				//and show the  data in the bottom textview.
				//Hint: data.getStringExtra()
			}
		}
	}
}
