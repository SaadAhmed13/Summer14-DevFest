package course.labs.permissionslab;

import course.labs.permissionslab.R;
import android.os.Bundle;
import android.provider.Browser;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;

public class Permissions extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_permissions);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		return true;
	}

	public void load(View view){
		String[] projection = 
			{
				Browser.BookmarkColumns.TITLE,
				Browser.BookmarkColumns.URL
			};
		
		Cursor query = getContentResolver().query(Browser.BOOKMARKS_URI, projection
				, null, null, null);
		
		String text = "";
		
		query.moveToFirst();
		
		while(query.moveToNext()){
			text += query.getString(query.getColumnIndex(Browser.BookmarkColumns.TITLE));
			text += "\n";
			text += query.getString(query.getColumnIndex(Browser.BookmarkColumns.URL));
			text += "\n\n";
		}
		
		EditText box = (EditText)findViewById(R.id.text);
		box.setText(text);
	
	}
	
	public void startCustomizationActivity(View view){
		//TODO: Launch the customization activity
	}
	
}
