package course.labs.fragmentslab;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class FriendsFragment extends ListFragment {

	private static final String[] FRIENDS = {
        "ladygaga",
        "msrebeccablack",
        "taylorswift13"
    };
	
	SelectionListener mCallback;

    public interface SelectionListener {
      
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public void onStart() {
        super.onStart();

        // When in two-pane layout, set the listview to highlight the selected list item
        // (We do this during onStart because at the point the listview is available.)
      
    }
    
    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        
        // This makes sure that the container activity has implemented
        // the callback interface. If not, it throws an exception
      
    }
	
    @Override
    public void onListItemClick(ListView l, View view, int position, long id) {
        // Send the event to the host activity
        
    }
    

}
