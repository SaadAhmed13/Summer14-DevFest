package course.labs.asynctasklab;

import java.util.Random;

public class QuoteItem {

	public final static String NAME = "name";
	public final static String QUOTE = "quote";
	
	String mName = new String();
	int mQuote = 0;
	
	QuoteItem(String name){
		mName = name;
		Random r = new Random();
		mQuote = 100 + (r.nextInt(100));
	}
	
	public void setName(String name){
		mName = name;
	}
	
	public String getName(){
		return mName;
	}
	
	public void setQuote(int quote){
		mQuote = quote;
	}
	
	public String getQuote(){
		return "" + mQuote;
	}
	
	public String toString(){
		return mName + "\n" + mQuote;
	}
}
