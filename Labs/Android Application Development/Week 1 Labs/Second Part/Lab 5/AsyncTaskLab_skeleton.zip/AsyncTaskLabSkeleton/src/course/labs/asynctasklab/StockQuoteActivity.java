package course.labs.asynctasklab;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import android.app.ListActivity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;

public class StockQuoteActivity extends ListActivity {

	private static final String SYMBOL_TAG = "symbol";

	private static final String SAVE_FILE = "course.labs.asynctasklab.StockQuoteActivity";

	private static final String TAG = "StockQuoteActivity";

	private QuoteListAdapter mListAdapter;

	private static final int NORMAL_FREQ = 15000;
	private static final int INITIAL_REFRESH_BOUNDARY = 20;

	// Handler for refreshes
	private final Handler mHandler = new Handler();

	// Should the quotes be periodically updated?
	private boolean mIsRefreshing;

	// Is the Activity in or about to go in the foreground?
	private boolean mIsForeground;

	// The BroadcastReceiver that listens for ACTION_BATTERY_LOW and
	// ACTION_BATTERY_OKAY
	BroadcastReceiver mBatteryReceiver = new BroadcastReceiver() {

		public void onReceive(Context context, Intent intent) {
			Log.i(TAG, "onReceive:" + intent.getAction());

			if (intent.getAction().equals(Intent.ACTION_BATTERY_LOW)) {
				Log.i(TAG, "ACTION_BATTERY_LOW");
				mIsRefreshing = false;
			} else if (intent.getAction().equals(Intent.ACTION_BATTERY_OKAY)) {
				Log.i(TAG, "ACTION_BATTERY_OKAY");

				mIsRefreshing = true;

				mHandler.removeCallbacksAndMessages(null);

				if (mIsForeground)
					mHandler.post(mHandlerTask);
			}
		}
	};

	// Runnable that performs a stock quote update and
	// then schedules the next update, if appropriate.
	

	private Runnable mHandlerTask = new Runnable() {

		@Override
		public void run() {

			// TODO 1
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		mListAdapter = new QuoteListAdapter(loadItems(),
				getApplicationContext());

		getListView().setFooterDividersEnabled(true);

		LinearLayout footerView = (LinearLayout) getLayoutInflater().inflate(
				R.layout.footer_view, null);

		footerView.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivityForResult(new Intent(StockQuoteActivity.this,
						AddQuoteActivity.class), 0);
			}
		});

		getListView().addFooterView(footerView);

		setListAdapter(mListAdapter);

		Intent batteryStatus = registerReceiver(null, new IntentFilter(
				Intent.ACTION_BATTERY_CHANGED));

		if (((batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100) / batteryStatus
				.getIntExtra(BatteryManager.EXTRA_SCALE, 100)) > INITIAL_REFRESH_BOUNDARY) {

			mIsRefreshing = true;

		}

		registerBatteryReceiver();

	}

	private void registerBatteryReceiver() {
		IntentFilter f = new IntentFilter();
		f.addAction(Intent.ACTION_BATTERY_LOW);
		f.addAction(Intent.ACTION_BATTERY_OKAY);

		registerReceiver(mBatteryReceiver, f);
	}

	// stop updates when the Activity is paused

	@Override
	public void onPause() {
		super.onPause();

		// Cancel pending refreshes
		mHandler.removeCallbacksAndMessages(null);

		mIsForeground = false;
	}

	// restart updates if appropriate when Activity
	// returns to the foreground

	@Override
	public void onResume() {
		super.onResume();

		mIsForeground = true;

		if (mListAdapter.getCount() > 0 && mIsRefreshing) {
			mHandler.postDelayed(mHandlerTask, NORMAL_FREQ);
		}
	}

	// Unregister BroadcastReceiver and save stock symbols
	@Override
	protected void onDestroy() {

		unregisterReceiver(mBatteryReceiver);

		PrintWriter writer = null;
		try {
			FileOutputStream fos = openFileOutput(SAVE_FILE, MODE_PRIVATE);
			writer = new PrintWriter(new BufferedWriter(new OutputStreamWriter(
					fos)));
			for (int idx = 0; idx < mListAdapter.getCount(); idx++) {
				writer.println(((QuoteItem) mListAdapter.getItem(idx))
						.getName());
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (null != writer) {
				writer.close();
			}
		}

		super.onDestroy();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {

		// Process new Stock Symbol
		if (requestCode == 0 && resultCode == RESULT_OK) {

			// Get the symbol and create a new QuoteItem
			QuoteItem tmp = new QuoteItem(data.getStringExtra(SYMBOL_TAG));
			mListAdapter.add(tmp);

		}
	}

	private List<QuoteItem> loadItems() {
		BufferedReader reader = null;
		List<QuoteItem> items = new CopyOnWriteArrayList<QuoteItem>();

		try {
			FileInputStream fis = openFileInput(SAVE_FILE);
			reader = new BufferedReader(new InputStreamReader(fis));

			String name = null;

			while (null != (name = reader.readLine())) {
				items.add(new QuoteItem(name));

			}
		} catch (FileNotFoundException e) {
			Log.i(TAG, "File not found");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (null != reader) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return items;

	}

	//
	// ASyncTask code
	// TODO 2

	private class WorkTask extends
			AsyncTask<QuoteListAdapter, Void, String[]> {

		// Make progress bar visible 
		protected void onPreExecute() {

		}

		// Get current quotes and update them by 1
		// return String array with current quotes 
		
		protected String[] doInBackground(QuoteListAdapter... items) {

			// Simulate slow network
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}


			
		}

		// Make progress bar invisible
		// Use list adapter to set new quote values
		
		@Override
		protected void onPostExecute(String[] result) {

			findViewById(R.id.progress).setVisibility(View.GONE);

			for (int idx = 0; idx < result.length; idx++) {
				mListAdapter.setQuote(idx, result[idx]);
			}

		}

	}
}
