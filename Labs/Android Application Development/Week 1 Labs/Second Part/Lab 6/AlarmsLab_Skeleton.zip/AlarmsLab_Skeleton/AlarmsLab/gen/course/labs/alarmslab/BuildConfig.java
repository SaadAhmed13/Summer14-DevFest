/** Automatically generated file. DO NOT MODIFY */
package course.labs.alarmslab;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}