package course.labs.asynctasklab;

public class QuoteItem {

	// TODO: QuoteItems should now set and get  
	// 52-week high and 52-week low values
	// 
	public final static String NAME = "name";
	public final static String QUOTE = "quote";
	
	String mName = new String();
	double mQuote = 0;
	
	QuoteItem(String name){
		mName = name;
	}
	
	public void setName(String name){
		mName = name;
	}
	
	public String getName(){
		return mName;
	}
	
	public void setQuote(double quote){
		mQuote = quote;
	}
	
	public String getQuote(){
		return "" + mQuote;
	}
	
	public String toString(){
		return mName + "\n" + mQuote;
	}
}
