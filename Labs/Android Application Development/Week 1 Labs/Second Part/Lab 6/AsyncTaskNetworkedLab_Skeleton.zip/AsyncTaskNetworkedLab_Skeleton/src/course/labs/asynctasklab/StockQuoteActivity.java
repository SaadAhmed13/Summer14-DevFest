package course.labs.asynctasklab;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import android.app.ListActivity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;

public class StockQuoteActivity extends ListActivity {

	private static final String SYMBOL_TAG = "symbol";

	private static final String SAVE_FILE = "course.labs.asynctasklab.StockQuoteActivity";

	private static final String TAG = "StockQuoteActivity";

	private QuoteListAdapter mListAdapter;

	private static final int NORMAL_FREQ = 15000;
	private static final int INITIAL_REFRESH_BOUNDARY = 20;

	// Handler for refreshes
	private final Handler mHandler = new Handler();

	// Should the quotes be periodically updated?
	private boolean mIsRefreshing;

	// Is the Activity in or about to go in the foreground?
	private boolean mIsForeground;

	// The BroadcastReceiver that listens for ACTION_BATTERY_LOW and
	// ACTION_BATTERY_OKAY
	BroadcastReceiver mBatteryReceiver = new BroadcastReceiver() {

		public void onReceive(Context context, Intent intent) {
			Log.i(TAG, "onReceive:" + intent.getAction());

			if (intent.getAction().equals(Intent.ACTION_BATTERY_LOW)) {
				Log.i(TAG, "ACTION_BATTERY_LOW");
				mIsRefreshing = false;
			} else if (intent.getAction().equals(Intent.ACTION_BATTERY_OKAY)) {
				Log.i(TAG, "ACTION_BATTERY_OKAY");

				mIsRefreshing = true;

				mHandler.removeCallbacksAndMessages(null);

				if (mIsForeground)
					mHandler.post(mHandlerTask);
			}
		}
	};

	// Runnable that performs a stock quote update and
	// then schedules the next update

	private Runnable mHandlerTask = new Runnable() {

		@Override
		public void run() {

			new WorkTask().execute(mListAdapter);

			mHandler.removeCallbacksAndMessages(null);

			if (mIsRefreshing && mIsForeground)
				mHandler.postDelayed(mHandlerTask, NORMAL_FREQ);
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		mListAdapter = new QuoteListAdapter(loadItems(),
				getApplicationContext());

		getListView().setFooterDividersEnabled(true);

		LinearLayout footerView = (LinearLayout) getLayoutInflater().inflate(
				R.layout.footer_view, null);

		footerView.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivityForResult(new Intent(StockQuoteActivity.this,
						AddQuoteActivity.class), 0);
			}
		});

		getListView().addFooterView(footerView);

		setListAdapter(mListAdapter);

		Intent batteryStatus = registerReceiver(null, new IntentFilter(
				Intent.ACTION_BATTERY_CHANGED));

		if (((batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100) / batteryStatus
				.getIntExtra(BatteryManager.EXTRA_SCALE, 100)) > INITIAL_REFRESH_BOUNDARY) {

			mIsRefreshing = true;

		}

		registerBatteryReceiver();

	}

	private void registerBatteryReceiver() {
		IntentFilter f = new IntentFilter();
		f.addAction(Intent.ACTION_BATTERY_LOW);
		f.addAction(Intent.ACTION_BATTERY_OKAY);

		registerReceiver(mBatteryReceiver, f);
	}

	// Stop updates when the Activity is paused and save stock symbols

	@Override
	public void onPause() {
		super.onPause();

		mHandler.removeCallbacksAndMessages(null);

		mIsForeground = false;
		

		PrintWriter writer = null;
		try {
			FileOutputStream fos = openFileOutput(SAVE_FILE, MODE_PRIVATE);
			writer = new PrintWriter(new BufferedWriter(new OutputStreamWriter(
					fos)));
			
			// TODO: Save all the data
			for (int idx = 0; idx < mListAdapter.getCount(); idx++) {
				writer.println(((QuoteItem) mListAdapter.getItem(idx))
						.getName());
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (null != writer) {
				writer.close();
			}
		}
	}

	// restart updates if appropriate when Activity
	// returns to the foreground

	@Override
	public void onResume() {
		super.onResume();

		mIsForeground = true;

		if (mListAdapter.getCount() > 0 && mIsRefreshing) {
			mHandler.postDelayed(mHandlerTask, NORMAL_FREQ);
		}
	}

	// Unregister BroadcastReceiver
	@Override
	protected void onDestroy() {

		unregisterReceiver(mBatteryReceiver);

		super.onDestroy();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {

		// Process new Stock Symbol
		if (requestCode == 0 && resultCode == RESULT_OK) {

			// Get the symbol and create a new QuoteItem
			QuoteItem tmp = new QuoteItem(data.getStringExtra(SYMBOL_TAG));
			mListAdapter.add(tmp);

		}
	}

	private List<QuoteItem> loadItems() {
		BufferedReader reader = null;
		List<QuoteItem> items = new CopyOnWriteArrayList<QuoteItem>();

		try {
			FileInputStream fis = openFileInput(SAVE_FILE);
			reader = new BufferedReader(new InputStreamReader(fis));

			String name = null;

			// TODO: Load all the data items
			while (null != (name = reader.readLine())) {
				items.add(new QuoteItem(name));

			}
		} catch (FileNotFoundException e) {
			Log.i(TAG, "File not found");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (null != reader) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return items;

	}

	//
	// Async Task code
	//

	private class WorkTask extends
			AsyncTask<QuoteListAdapter, Void, String[]> {

		protected void onPreExecute() {
			findViewById(R.id.progress).setVisibility(View.VISIBLE);
		}

		// TODO: Ensure that calling this method causes all the data to be downloaded,
		// parsed, and displayed. 

		protected String[] doInBackground(QuoteListAdapter... items) {

			QuoteListAdapter adapter = items[0];

			// if there are no items at this time, don't waste your time
			if (adapter.getCount() == 0) {
				return (String[]) null;
			}

			String[] prices = new String[adapter.getCount()];

			for (int idx = 0; idx < items[0].getCount(); idx++) {
				String name = ((QuoteItem)adapter.getItem(idx)).getName();
				String price;
				try {
					price = getQuote(name);
				} catch (IOException e) {
					price = "-0.1";
				}
				prices[idx] = String.valueOf(price);
			}

			return prices;
		}

		// TODO: Update all data items for all companies
		@Override
		protected void onPostExecute(String[] result) {

			findViewById(R.id.progress).setVisibility(View.GONE);

			for (int idx = 0; idx < result.length; idx++) {
				mListAdapter.setQuote(idx, result[idx]);
			}

		}

	}
		
	//
	// Networking Handler
	// 

	private String getQuote(String company) throws IOException{
		InputStream inputStream = null;

		try {
			
			// TODO: Modify URL to request all data for multiple companies
			// all at one time
			
			URL url = new URL("http://finance.yahoo.com/d/quotes.csv?s="+company+"&f=b2");
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();

			connection.setReadTimeout(10000 /* milliseconds */);
			connection.setConnectTimeout(15000 /* milliseconds */);
			connection.setRequestMethod("GET");
			connection.setDoInput(true);
			// Starts the query
			connection.connect();

			inputStream = connection.getInputStream();

			// Convert the InputStream into a string
			String contentAsString = stringify(inputStream, 10);
			return contentAsString;

			// Makes sure that the InputStream is closed after the app is
			// finished using it.
		} finally {
			if (inputStream != null) {
				inputStream.close();
			} 
		}
	}

	// String conversion handler

	public String stringify(InputStream stream, int len) throws IOException, UnsupportedEncodingException {
		Reader reader = null;
		reader = new InputStreamReader(stream, "UTF-8");        
		char[] buffer = new char[len];
		reader.read(buffer);
		return new String(buffer);
	}			
}
