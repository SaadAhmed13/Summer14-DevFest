package course.labs.asynctasklab;

import java.util.List;

import course.labs.asynctasklab.R;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

public class QuoteListAdapter extends BaseAdapter {

	private final List<QuoteItem> mItems;
	private final Context mContext;
	
	public QuoteListAdapter(List<QuoteItem> items, Context context){
		mItems = items;
		mContext = context;	
	}
	
	@Override
	public int getCount() {
		return mItems.size();
	}

	@Override
	public Object getItem(int pos) {
		return mItems.get(pos);
	}

	@Override
	public long getItemId(int pos) {
		return pos;
	}
	
	public void setQuote(int pos, String quote){
		mItems.get(pos).setQuote(Double.parseDouble((quote)));
		notifyDataSetChanged();
	}

	public void add(QuoteItem item) {
		mItems.add(item);
		notifyDataSetChanged();
	}
	
	
	// TODO: The Views returned by this method should include the 
	// new data items
	@Override
	public View getView(int pos, View convertView, ViewGroup parent) {
		LinearLayout itemLayout;
		final QuoteItem item = mItems.get(pos);

		itemLayout = (LinearLayout) LayoutInflater.from(mContext).inflate(
				R.layout.quote_item, parent, false);
		
		TextView titleView = (TextView) itemLayout.findViewById(R.id.nameView);
		titleView.setText(item.getName());
		
		TextView quoteView = (TextView) itemLayout
				.findViewById(R.id.quoteView);
		Double quote = Double.parseDouble(item.getQuote());
		if(quote < 0){
			quoteView.setText("Error");
		} else { 
			quoteView.setText(item.getQuote());
		}
		
		return itemLayout;
	}

}
