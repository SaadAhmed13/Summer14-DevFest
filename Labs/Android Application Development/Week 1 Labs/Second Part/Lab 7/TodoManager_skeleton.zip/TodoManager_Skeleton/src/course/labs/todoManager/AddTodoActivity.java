package course.labs.todoManager;

import java.io.File;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentActivity;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.TimePicker;
import course.labs.todoManager.TodoItem.Priority;
import course.labs.todoManager.TodoItem.Status;

public class AddTodoActivity extends FragmentActivity {

	private static final int ADD_VOICE_NOTE = 0;
	private static final String TAG = "AddTodoActivity";
	private Date mDate;
	private static String mStringTime;
	private static String mStringDate;
	private static String mFileName = "NULL";

	public static final String STRING_FILENAME = "Todo.FILENAME";

	public static class DatePickerFragment extends DialogFragment implements
			DatePickerDialog.OnDateSetListener {

		@Override
		public Dialog onCreateDialog(Bundle savedInstanceState) {

			// Use the current date as the default date in the picker
			final Calendar c = Calendar.getInstance();
			int year = c.get(Calendar.YEAR);
			int month = c.get(Calendar.MONTH);
			int day = c.get(Calendar.DAY_OF_MONTH);

			// Create a new instance of DatePickerDialog and return it
			return new DatePickerDialog(getActivity(), this, year, month, day);
		}

		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			mStringDate = year + "-" + monthOfYear + "-" + dayOfMonth;
			TextView dateView = (TextView) getActivity()
					.findViewById(R.id.date);
			dateView.setText(mStringDate);
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {

		// TODO -- Get Voice Note filename from data intent

	}

	public static class TimePickerFragment extends DialogFragment implements
			TimePickerDialog.OnTimeSetListener {

		@Override
		public Dialog onCreateDialog(Bundle savedInstanceState) {

			// Use the current time as the default values for the picker
			final Calendar c = Calendar.getInstance();
			int hour = c.get(Calendar.HOUR_OF_DAY);
			int minute = c.get(Calendar.MINUTE);

			// Create a new instance of TimePickerDialog and return it
			return new TimePickerDialog(getActivity(), this, hour, minute,
					DateFormat.is24HourFormat(getActivity()));
		}

		public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

			mStringTime = hourOfDay + ":" + minute + ":00";
			TextView timeView = (TextView) getActivity()
					.findViewById(R.id.time);
			timeView.setText(mStringTime);
		}
	}

	public void showDatePickerDialog(View v) {

		DialogFragment newFragment = new DatePickerFragment();
		newFragment.show(getSupportFragmentManager(), "datePicker");

	}

	public void showTimePickerDialog(View v) {

		DialogFragment newFragment = new TimePickerFragment();
		newFragment.show(getSupportFragmentManager(), "datePicker");

	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add_todo);

		final EditText title = (EditText) findViewById(R.id.title);
		final RadioGroup status = (RadioGroup) findViewById(R.id.statusGroup);
		final RadioButton defaultStatusButton = (RadioButton) findViewById(R.id.statusNotDone);
		final RadioGroup priority = (RadioGroup) findViewById(R.id.priorityGroup);
		final RadioButton defaultPriorityButton = (RadioButton) findViewById(R.id.medPriority);

		// Cancel Add ToDoItem Operation
		Button cancelButton = (Button) findViewById(R.id.cancelButton);
		cancelButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				setResult(RESULT_CANCELED);
				finish();
			}
		});

		// Button for adding Voice Note to ToDoItem
		Button voiceButton = (Button) findViewById(R.id.voiceButton);
		voiceButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				// TODO -- start activity to record VoiceNote and return the filename 
				// where the VoiceNote is stored 
			}

		});

		// Reset Fields to initial values
		// Delete VoiceNote if it exists
		
		Button resetButton = (Button) findViewById(R.id.resetButton);
		resetButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				title.setText("");
				defaultPriorityButton.setChecked(true);
				defaultStatusButton.setChecked(true);
				deleteVoiceNote();
			}

			// Deletes Voice Note from file system
			private void deleteVoiceNote() {
				if (!mFileName.equals("NULL")) { 	 
						File f = new File (mFileName);
						if (f.exists()) {
							f.delete();
						}
						mFileName = "NULL";
				}
			}
		});

		Button submitButton = (Button) findViewById(R.id.submitButton);
		submitButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				String pval = null;
				switch (priority.getCheckedRadioButtonId()) {
				case R.id.lowPriority: {
					pval = Priority.LOW.toString();
					break;
				}
				case R.id.medPriority: {
					pval = Priority.MED.toString();
					break;
				}
				case R.id.highPriority: {
					pval = Priority.HIGH.toString();
					break;
				}
				}

				String sval = null;
				switch (status.getCheckedRadioButtonId()) {
				case R.id.statusDone: {
					sval = Status.DONE.toString();
					break;
				}
				case R.id.statusNotDone: {
					sval = Status.NOTDONE.toString();
					break;
				}
				}

				Intent data = new Intent();
				String titleString = title.getText().toString();
				if (titleString.equals(""))
					titleString = "No Title";
				// if date field is left empty, just set the expiration for 1
				// week from now
				if (mStringDate == null && mStringTime == null) {
					mDate = new Date();
					mDate = new Date(mDate.getTime() + 604800000);
				}
				// if only date is used and time is left unused set time at
				// 12:00am
				if (mStringDate != null && mStringTime == null) {
					try {
						mDate = TodoItem.FORMAT.parse(mStringDate + " "
								+ "00:00:00");
					} catch (ParseException e) {
						Log.i(TAG, "Could not parse date");
						e.printStackTrace();
					}
				}
				// if only time is set and date is left unused, set date as
				// today
				if (mStringDate == null && mStringTime != null) {
					Calendar c = Calendar.getInstance();
					int hour = Integer.parseInt(mStringTime.substring(0, 2));
					int minute = Integer.parseInt(mStringTime.substring(3, 5));
					c.set(Calendar.HOUR_OF_DAY, hour);
					c.set(Calendar.MINUTE, minute);
					c.set(Calendar.SECOND, 0);

					mDate = c.getTime();
				}

				data.putExtra(TodoItem.TITLE, titleString);
				data.putExtra(TodoItem.PRIORITY, pval);
				data.putExtra(TodoItem.STATUS, sval);
				data.putExtra(TodoItem.DATE, TodoItem.FORMAT.format(mDate));
				data.putExtra(TodoItem.EXTRA_FILENAME, mFileName);

				setResult(RESULT_OK, data);
				finish();
			}
		});
	}
}
