package course.labs.todoManager;

import java.text.SimpleDateFormat;
import java.util.Date;

public class TodoItem {

	public enum Priority {
		LOW, MED, HIGH
	};

	public enum Status {
		NOTDONE, DONE
	};

	public final static String TITLE = "title";
	public final static String PRIORITY = "priority";
	public final static String STATUS = "status";
	public final static String DATE = "date";
	
	// String used to identify the filename String Extra
	public final static String EXTRA_FILENAME = "filename";
	
	// FIX: Update to support user locale 
	public final static SimpleDateFormat FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	String mTitle = new String();
	Priority mPriority = Priority.LOW;
	Status mStatus = Status.NOTDONE;
	Date mDate = new Date();

	// TODO -- Add a new field containing the file name in which the VoiceNote is stored
	// Add code wherever else you need to to manage that new field 

	TodoItem(String title, Priority priority, Status status, Date date) {
		this.mTitle = title;
		this.mPriority = priority;
		this.mStatus = status;
		this.mDate = date;
	}

	public String getTitle() {
		return mTitle;
	}

	public void setTitle(String title) {
		this.mTitle = title;
	}

	public Priority getPriority() {
		return mPriority;
	}

	public void setPriority(Priority priority) {
		this.mPriority = priority;
	}

	public Status getStatus() {
		return mStatus;
	}

	public void setStatus(Status status) {
		this.mStatus = status;
	}
	
	public Date getDate(){
		return mDate;
	}
	
	public void setDate(Date date){
		this.mDate = date;
	}

	public String toString() {
		return mTitle + "\n" + mPriority + "\n" + mStatus + "\n" + FORMAT.format(mDate) + "\n";
	}
}
