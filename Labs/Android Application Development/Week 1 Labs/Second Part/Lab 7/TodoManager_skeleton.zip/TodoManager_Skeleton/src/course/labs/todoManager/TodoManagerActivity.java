package course.labs.todoManager;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.Date;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.Toast;
import course.labs.todoManager.TodoItem.Priority;
import course.labs.todoManager.TodoItem.Status;

public class TodoManagerActivity extends ListActivity {

	private static final String TODO_DATA_FILE = "course.labs.todoManager.TodoManagerActivity.items";
	private static final int CREATE_NEW_TODO_ITEM = 0;
	public static final String TAG = "TodoManagerActivity";
	private TodoListAdapter mAdapter;
	private static MediaPlayer mPlayer;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		mAdapter = new TodoListAdapter(getApplicationContext());

		getListView().setFooterDividersEnabled(true);

		LinearLayout footerView = (LinearLayout) LayoutInflater.from(
				TodoManagerActivity.this).inflate(R.layout.footer_view, null);

		footerView.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivityForResult(new Intent(TodoManagerActivity.this,
						AddTodoActivity.class), CREATE_NEW_TODO_ITEM);
			}
		});

		getListView().addFooterView(footerView);

		loadItems();
		
		setListAdapter(mAdapter);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {

		// Get date
		if (requestCode == CREATE_NEW_TODO_ITEM && resultCode == RESULT_OK) {

			Date date;
			try {
				date = TodoItem.FORMAT
						.parse(data.getStringExtra(TodoItem.DATE));
			} catch (ParseException e) {
				date = new Date();
			}

			// TODO -- Create a new TodoItem for the data stored in the data Intent.
			// make sure you include the VoiceNote's file name
			
			TodoItem tmp = /* ...  */
			
			// Add new TodoItem to list adapter
			mAdapter.add(tmp);

		}
	}

	public static void play(Context context, String filename) {

		//TODO:
		//if filename = "NULL" display a Toast message
		//Otherwise use a MediaPlayer instance to play the VoiceNote

	}

	private void loadItems() {
		BufferedReader reader = null;
		try {
			FileInputStream fis = openFileInput(TODO_DATA_FILE);
			reader = new BufferedReader(new InputStreamReader(fis));
			String title = null;
			String priority = null;
			String status = null;
			Date date = null;
			String name = null;
			while (null != (title = reader.readLine())) {
				priority = reader.readLine();
				status = reader.readLine();
				date = TodoItem.FORMAT.parse(reader.readLine());
				name = reader.readLine();
				
				mAdapter.add(
						
						// TODO -- create new TodoItem
						
						);
				
				
			}
		} catch (FileNotFoundException e) {
			Log.i(TAG, "File not found");
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			Log.i(TAG, "Could not parse date");
		} finally {
			if (null != reader) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	protected void onDestroy() {
		PrintWriter writer = null;
		try {
			FileOutputStream fos = openFileOutput(TODO_DATA_FILE, MODE_PRIVATE);
			writer = new PrintWriter(new BufferedWriter(new OutputStreamWriter(
					fos)));
			for (int idx = 0; idx < mAdapter.getCount(); idx++) {
				writer.println(mAdapter.getItem(idx));
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (null != writer) {
				writer.close();
			}
		}
		super.onStop();
	}
}