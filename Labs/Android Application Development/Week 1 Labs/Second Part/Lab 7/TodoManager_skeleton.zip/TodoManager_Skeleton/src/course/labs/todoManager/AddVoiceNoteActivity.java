package course.labs.todoManager;

import java.io.File;
import java.io.IOException;
import java.util.Random;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.AudioManager.OnAudioFocusChangeListener;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.Toast;
import android.widget.ToggleButton;

public class AddVoiceNoteActivity extends Activity {

	private static final String TAG = "TodoManagerActivity";

	private static final String mFilePath = Environment
			.getExternalStorageDirectory().getAbsolutePath();
	private static String mFileName = "";
	private MediaRecorder mRecorder;
	private MediaPlayer mPlayer;
	private AudioManager mAudioManager;
	
	// true if a VoiceNote has been recorded 
	private static boolean hasVoiceNote = false;
	
	public static final String FULL_FILENAME = "AddVoiceNote.FILENAME";

	private ToggleButton mPlayButton;
	private ToggleButton mRecordButton;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add_voice_note);

		// Define a unique filename for the VoiceNote
		mFileName = "/Todo_" + newFileName() + ".3gp";

		mRecordButton = (ToggleButton) findViewById(R.id.record);
		mPlayButton = (ToggleButton) findViewById(R.id.play);
		final Button mSubmitButton = (Button) findViewById(R.id.submit);

		mRecordButton.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {

				mPlayButton.setEnabled(!isChecked);
				onRecordPressed(isChecked);

			}
		});

		mPlayButton.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {

				mRecordButton.setEnabled(!isChecked);
				onPlayPressed(isChecked);
			
			}
		});

		mSubmitButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {

				// TODO -- return the filename if a voice note has
				// been recorded
				// Show Toast Message otherwise
			}
		});

		
		// TODO -- Add Cancel and Reset Buttons
		
		
		// Request audio focus
		mAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
		mAudioManager.requestAudioFocus(afChangeListener,
				AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);

	}

	private void onRecordPressed(boolean shouldStartRecording) {

		if (shouldStartRecording) {
		
			startRecording();
			hasVoiceNote = false;
		
		} else {
			
			stopRecording();
			hasVoiceNote = true;
		
		}
	}

	private void startRecording() {

		// TODO 
	}

	private void stopRecording() {

		// TODO 
	}

	private void onPlayPressed(boolean shouldStartPlaying) {
		
		if (shouldStartPlaying) {
		
			startPlaying();
		
		} else {
		
			stopPlaying();
		
		}
	}

	private void startPlaying() {

		//TODO
	}

	private void stopPlaying() {

		// TODO 
		
		}
	}

	// Listen for Audio focus changes
	OnAudioFocusChangeListener afChangeListener = new OnAudioFocusChangeListener() {
		public void onAudioFocusChange(int focusChange) {

			if (focusChange == AudioManager.AUDIOFOCUS_LOSS) {
			
				mAudioManager.abandonAudioFocus(afChangeListener);
				if (null != mPlayer && mPlayer.isPlaying())
					stopPlaying();
			
			}
		}
	};

	@Override
	public void onPause() {
		super.onPause();
		
		if (null != mRecorder) {
		
			mRecorder.release();
			mRecorder = null;
		
		}

		if (null != mPlayer) {
			mPlayer.release();
			mPlayer = null;
		}
	}

	private String newFileName() {

		Random r = new Random();
		String fName;

		do {

			fName = String.valueOf(r.nextLong());

		} while ((new File(fName)).exists());

		return fName;
	}
}
