package course.labs.todoManager;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import course.labs.todoManager.TodoItem.Status;

public class TodoListAdapter extends ArrayAdapter<TodoItem> {

	private final List<TodoItem> mItems = new ArrayList<TodoItem>();
	private final Context mContext;

	public TodoListAdapter(Context context) {
		super(context, 0);

		mContext = context;
	}

	@Override
	public int getCount() {
		return mItems.size();
	}

	@Override
	public TodoItem getItem(int pos) {
		return mItems.get(pos);
	}

	@Override
	public long getItemId(int pos) {
		return pos;
	}

	@Override
	public void add(TodoItem item) {
		mItems.add(item);
		notifyDataSetChanged();
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		LinearLayout itemLayout;
		final TodoItem item = mItems.get(position);

		itemLayout = (LinearLayout) LayoutInflater.from(mContext).inflate(
				R.layout.todo_item, parent, false);

		TextView titleView = (TextView) itemLayout.findViewById(R.id.titleView);
		titleView.setText(item.getTitle());

		CheckBox statusView = (CheckBox) itemLayout
				.findViewById(R.id.statusCheckBox);
		statusView.setChecked(item.getStatus().equals(TodoItem.Status.DONE));
		statusView.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				item.setStatus(isChecked ? Status.DONE : Status.NOTDONE);
			}
		});

		TextView priorityView = (TextView) itemLayout
				.findViewById(R.id.priorityView);
		priorityView.setText(item.getPriority().toString());

		TextView dateView = (TextView) itemLayout.findViewById(R.id.dateView);
		dateView.setText(TodoItem.FORMAT.format(item.getDate()));

		if (item.getDate().before(new Date())
				&& item.getStatus() == Status.NOTDONE) {
			itemLayout.setBackgroundColor(Color.parseColor("#9E3C5D"));
		}

		
		ImageView imageView = (ImageView) itemLayout.findViewById(R.id.play);

		// TODO -- Add the Play Button and set its onClickListener if the TodoItem has a VoiceNote

		return itemLayout;
	}
}
