package edu.calpoly.android.walkabout;

import java.util.ArrayList;

import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuItem.OnMenuItemClickListener;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.MyLocationOverlay;
import com.google.android.maps.OverlayItem;

public class WalkAbout extends MapActivity {

	
	private MapView m_vwMap;
	private MapController m_mapController;
	private PathOverlay m_pathOverlay;
	private MyLocationOverlay m_locationOverlay;
	
	private ArrayList<GeoPoint> m_arrPathPoints;
	private ArrayList<OverlayItem> m_arrPicturePoints;
	private LocationManager m_locManager;
	private boolean m_bRecording;

	private static final double GEO_CONVERSION = 1E6;
	private static final int MIN_TIME_CHANGE = 3000;
	private static final int MIN_DISTANCE_CHANGE = 3;
	
	private static final int PICTURE_REQUEST_CODE = 0;
	private static final int ENABLE_GPS_REQUEST_CODE = 1;
	
	private static final int STARTSTOP_MENU_ITEM = Menu.FIRST;
	private static final int SAVE_MENU_ITEM = Menu.FIRST+1;
	private static final int LOAD_MENU_ITEM = Menu.FIRST+2;
	private static final int PICTURE_MENU_ITEM = Menu.FIRST+3;
	private static final int ENABLEGPS_MENU_ITEM = Menu.FIRST+4;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); 
        initLocationData();
        initLayout(); 
    }
	@Override
	protected boolean isRouteDisplayed() {
		return false;
	}
    
    private void initLocationData() {
    	// TODO
    }
    
	private void initLayout() {
    	// TODO
    }
	
	private void setRecordingState(boolean bRecording) {
		// TODO
	}
	
	private void saveRecording() {
		// TODO
	}
	
	private void loadRecording() {
		// TODO
	}
}