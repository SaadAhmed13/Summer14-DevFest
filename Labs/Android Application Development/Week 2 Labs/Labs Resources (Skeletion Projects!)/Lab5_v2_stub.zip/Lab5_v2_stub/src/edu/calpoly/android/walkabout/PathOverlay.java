package edu.calpoly.android.walkabout;

import java.util.List;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.RectF;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.Projection;

public class PathOverlay extends Overlay {

	private final List<GeoPoint> m_arrPathPoints;
	
	private Point m_point;
	private Point m_point2;
	private Paint m_paint;
	private RectF m_rect;
	
	private static final int START_RADIUS = 10;
	private static final int PATH_WIDTH = 6;
	

	public PathOverlay(List<GeoPoint> pathPoints) {
		super();
    	// TODO
		m_arrPathPoints = null;
	}
		
	@Override
	public void draw(Canvas canvas, MapView mapView, boolean shadow) {
    	// TODO
	}
}
