package edu.calpoly.lab7;

import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.os.Bundle;

public class AccelActivity extends Activity implements SensorEventListener {

	public static final int ACC_X = 0;
	public static final int ACC_Y = 1;
	public static final int ACC_Z = 2;

	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.accel);
		registerWithSensor();
    }
	
	private void registerWithSensor() {
		// TODO
	}

	@Override
	public void onSensorChanged(SensorEvent event) {
		// TODO
	}
	
	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
	}
}
