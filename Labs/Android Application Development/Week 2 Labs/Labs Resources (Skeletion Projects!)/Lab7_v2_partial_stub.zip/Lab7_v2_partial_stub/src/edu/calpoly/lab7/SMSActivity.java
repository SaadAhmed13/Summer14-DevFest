package edu.calpoly.lab7;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SMSActivity extends Activity {
	private static final String SMS_SENT = "SMS_SENT";
	private static final String SMS_DELIVERED = "SMS_DELIVERED";
	
	private PendingIntent pendingSent = null;
	private PendingIntent pendingDelivered = null;

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms);
        ((Button)findViewById(R.id.sendButton)).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				//Send SMS Message
				sendSMS();
				resetUI();
			}
        });
        ((Button)findViewById(R.id.resetButton)).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
		    	//Cancel Pending Intents
				cancelStatusUpdates();
				resetUI();
			}
        });
        initStatusReceivers();
    }
	
	private void initStatusReceivers() {
		// TODO
	}
	
	private void sendSMS() {
		// TODO
	}
	
	private void cancelStatusUpdates() {
		// TODO
	}
	
	private void resetUI() {

    	//Reset Status
    	((TextView)findViewById(R.id.statusText)).setText(R.string.unsent);
    	
    	//Clear Phone Number
    	((EditText)findViewById(R.id.messageNumber)).setText("");
    	
    	//Clear Message
    	((EditText)findViewById(R.id.messageText)).setText("");
	}
	
	private class MessageSentReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO
		}
	}
	
	private class MessageDeliveredReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO
		}
	}

}
