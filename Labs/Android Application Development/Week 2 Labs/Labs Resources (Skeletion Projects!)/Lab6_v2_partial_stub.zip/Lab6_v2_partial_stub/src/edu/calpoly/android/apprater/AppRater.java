package edu.calpoly.android.apprater;


import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.widget.ListView;
import edu.calpoly.android.appraterkey.AppContentProvider;
import edu.calpoly.android.appraterkey.AppDownloadService;

public class AppRater extends Activity {

	/** MenuItem Constants to be used for the Options Menu **/
	private static final int MENU_ITEM_STARTDOWNLOAD = Menu.FIRST;
	private static final int MENU_ITEM_STOPDOWNLOAD = Menu.FIRST + 1;
	private static final int MENU_ITEM_REMOVEALL = Menu.FIRST+2;

	/** MenuItem Constants to be used for the Context Menu **/
	private static final int MENU_ITEM_INSTALLED = Menu.FIRST;
	private static final int MENU_ITEM_RATING1 = Menu.FIRST + 1;
	private static final int MENU_ITEM_RATING2 = Menu.FIRST + 2;
	private static final int MENU_ITEM_RATING3 = Menu.FIRST + 3;
	private static final int MENU_ITEM_RATING4 = Menu.FIRST + 4;
	private static final int MENU_RATING_GROUP = Menu.FIRST;

	/** The ListView that contains the List of AppViews. **/
	private ListView m_vwAppList;

	/** The Cursor that contains the Apps. **/
	private Cursor m_cursorApps;

	/** The CursorAdapter used to bind the Cursor to AppViews. **/
	private AppCursorAdapter m_cursorAdapter;

	/**
	 * The BroadcastReceiver used to listen for new Apps that have been added by
	 * the AppDownloadService.
	 */
	private AppReceiver m_receiver;

	private static final String ORDER_BY_STRING = AppContentProvider.APP_KEY_INSTALLED + ", " +
												  AppContentProvider.APP_KEY_RATING + ", " +
												  AppContentProvider.APP_KEY_NAME;
	
	private static final int NOTIFICATION_ID = AppDownloadService.NEW_APP_NOTIFICATION_ID;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.app_list);

		// Init Cursor & Adapter
		// TODO

		// Init View Components
		// TODO
	}

	/**
	 * Inner class that defines a BroadcastReciever which listens for Intents
	 * broadcasted by the AppDownloadService when it has downloaded a new App.
	 */
	public class AppReceiver extends BroadcastReceiver {

		/**
		 * This method gets called when the AppDownloadService broadcasts
		 * intents
		 */
		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO
		}
	}
}